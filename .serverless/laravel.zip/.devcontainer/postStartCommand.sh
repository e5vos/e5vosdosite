cd src
php artisan serve & 
npm run dev