export type Status = 'idle' | 'loading' | 'succeeded' | 'failed'
