<?php

namespace App\Helpers;

/**
 * App\Helpers\PermissionType
 * DO NOT CHANGE, WILL FUCK UP DB
 */
enum EjgClassType: string
{
    case sevenA = '7.A';
    case sevenB = '7.B';
    case eightA = '8.A';
    case eightB = '8.B';
    case nineA = '9.A';
    case nineB = '9.B';
    case nineC = '9.C';
    case nineD = '9.D';
    case nineE = '9.E';
    case nineF = '9.F';
    case nineNY = '9.NY';
    case tenA = '10.A';
    case tenB = '10.B';
    case tenC = '10.C';
    case tenD = '10.D';
    case tenE = '10.E';
    case tenF = '10.F';
    case elevenA = '11.A';
    case elevenB = '11.B';
    case elevenC = '11.C';
    case elevenD = '11.D';
    case elevenE = '11.E';
    case elevenF = '11.F';
    case twelveA = '12.A';
    case twelveB = '12.B';
    case twelveC = '12.C';
    case twelveD = '12.D';
    case twelveE = '12.E';
    case twelveF = '12.F';
    case teacher = 'tanár';
    case oldDude = 'öregdiák';
}
