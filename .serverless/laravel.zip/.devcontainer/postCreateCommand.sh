cd src
composer install
npm install
php artisan migrate
