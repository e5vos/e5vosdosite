interface Window {
    statusCode: number | undefined
    message: string | undefined
}
