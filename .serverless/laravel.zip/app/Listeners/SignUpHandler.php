<?php

namespace App\Listeners;

use App\Events\EventSignup;

class SignUpHandler
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @return void
     */
    public function handle(EventSignup $event)
    {
        //
    }
}
