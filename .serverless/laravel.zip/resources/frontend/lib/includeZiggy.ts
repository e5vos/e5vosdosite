import { Config } from 'ziggy-js'

import { Ziggy } from '../../js/ziggy'

export default Ziggy as Config
