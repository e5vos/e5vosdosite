<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="icon" type="image/svg+xml" href="/whitedonci.svg" />
    <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
    <link rel="mask-icon" href="/mask-icon.svg" color="#FFFFFF" />

    <meta name="msapplication-TileColor" content="#FFFFFF" />
    <meta name="theme-color" content="#FFFFFF" />

    <title>Eötvös DÖ</title>
    <meta name="description" content="Eötvös DÖ " />
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <script type="module" crossorigin src="/assets/main.87f3c8ae.js"></script>
    <link rel="stylesheet" href="/assets/main.2a74ab53.css">
    @viteReactRefresh
    @vite(['resources/frontend/main.tsx'])
    <!-- Scripts -->
</head>

<body>
    <div id="root"></div>

</body>

</html>
