<?php

namespace App\Helpers;

/**
 * App\Helpers\SlotType
 * DO NOT CHANGE, WILL FUCK UP DB
 */
enum SlotType: string
{
    case presentation = 'Előadássáv';
    case program = 'Programsáv';
}
